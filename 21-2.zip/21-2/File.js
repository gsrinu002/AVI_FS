
    document.getElementsByTagName("h1")[0].innerHTML="Dubai"
    document.getElementsByTagName("h1")[1].innerHTML = "Dubai"
    document.getElementsByTagName("h1")[2].innerHTML = "Dubai"
    document.getElementsByTagName('h2')[0].innerHTML="Dubai "