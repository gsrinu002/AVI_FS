
// define function 

function sayHello()
{
    // function body
    alert("function calling")
}
//calling function 
sayHello()

// function with parameteres 

function addition(a, b)
{
    var c = a + b
    alert("addition is" + c)
}

//calling function 
addition(10,34)

// function with return type 

function addition_1(x, y)
{
    z = x + y
    return z
}
var my_addition = addition_1(100, 200)
document.write(my_addition)
console.log(my_addition)
alert(my_addition)

// function with names

function full_name(fname,lname)
{
    var full_name = fname + lname
    alert(full_name)
}
// calling function 
full_name('sreenivas', 'Gorantla')

